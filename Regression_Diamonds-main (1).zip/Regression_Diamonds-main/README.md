# Diamonds Price prediction
## MVP

The goal of this project is to perform a regression model to predict the price of diamonds.

![Diamonds ](https://user-images.githubusercontent.com/93079353/145090896-b98ceefd-9935-4f4c-8d7b-c036a2dbf3f3.png)

To start exploring this goal, We used heatmap plot to shows the relations between the features.

The figure describes which correlation is strong and weak. This result shows that Carat has the strong correlation with Price.
