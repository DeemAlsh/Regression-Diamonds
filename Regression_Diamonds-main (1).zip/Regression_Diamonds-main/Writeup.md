# Abstract

The goal of this project was to perform regression model to predict the price of diamonds. We worked with dataset which has a lot of features
to do analysis and prediction of the Diamonds.

# Design

This project dataset was provided by Kaggle, We use this data to bulid a model to predict the Diamonds price.

# Data

The Diamonds dataset contains a few feature include Carat, Price, Cut, Color, Clarity, depth and Table. 

Raws:53,940 rows
Columns: 10 columns, which are Carat, Price, Cut, Color, Clarity, depth, Tabel and (x represent length, y represent width and z represent depth)


# Algorithms

- Linear regression 
- Ridge
- Polynomial 
- Random forest

# Tools

- Http 
- Beautiful soup for web scraping 
- Python Jupyter Notebook
- Numpy and Pandas for data manipulation
- Matplotlib and Seaborn for plotting
- sklearn for machine learning

# Communication

After testing our model this figuer shows how we got a perfct predict on our model.

![bokeh_plot](https://user-images.githubusercontent.com/93079353/145187473-95604583-88a1-4a10-8b58-056e5fcc0af0.png)



